
package com.example.darusam.database

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.darusam.models.Drug

@Dao
interface DrugDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(drug: Drug)

    @Query("SELECT * FROM drugs WHERE quantity < minRequired ORDER BY name ASC")
    fun getLowStockDrugs(): LiveData<List<Drug>>
}
