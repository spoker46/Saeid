
package com.example.darusam.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.darusam.databinding.ItemDrugBinding
import com.example.darusam.models.Drug

class DrugAdapter(private val drugs: List<Drug>) :
    RecyclerView.Adapter<DrugAdapter.DrugViewHolder>() {

    class DrugViewHolder(val binding: ItemDrugBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DrugViewHolder {
        val binding = ItemDrugBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return DrugViewHolder(binding)
    }

    override fun onBindViewHolder(holder: DrugViewHolder, position: Int) {
        val drug = drugs[position]
        holder.binding.textViewName.text = drug.name
        holder.binding.textViewQuantity.text = "موجودی: ${drug.quantity}"
    }

    override fun getItemCount(): Int = drugs.size
}
