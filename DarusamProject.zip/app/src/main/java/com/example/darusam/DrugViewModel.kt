
package com.example.darusam

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.darusam.database.DrugDao
import com.example.darusam.models.Drug

class DrugViewModel(private val drugDao: DrugDao) : ViewModel() {
    val lowStockDrugs: LiveData<List<Drug>> = drugDao.getLowStockDrugs()
}

class DrugViewModelFactory(private val drugDao: DrugDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DrugViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return DrugViewModel(drugDao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
