
package com.example.darusam

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.darusam.adapters.DrugAdapter
import com.example.darusam.database.AppDatabase
import com.example.darusam.database.DrugDao
import com.example.darusam.databinding.ActivityMainBinding
import com.example.darusam.models.Drug

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val viewModel: DrugViewModel by viewModels {
        DrugViewModelFactory(AppDatabase.getDatabase(this).drugDao())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerView.layoutManager = LinearLayoutManager(this)

        viewModel.lowStockDrugs.observe(this) { drugs ->
            binding.recyclerView.adapter = DrugAdapter(drugs)
        }
    }
}
